<b><h1>Teste-DLL-Companytec-Delphi</b></h1>
<p> Repositório criado para o versionamento do software utilizado para testes utilizando a DLL Companytec.<p>
<p> Lembrando que este software anda quase junto com a atualização da DLL.</p>
<p> Todas as alterações realizadas e comandos implementados estão descritos abaixo<p>
<h1></h1>

### Versão 1.0 - 13/02/2020
```
- Inicializado o versionamento;
- Colocado comando para leitura de registro de identificador e comando de visualização identificada.
```

### Versão 1.1 - 28/07/2020
```
- Colocado comando para sincronizar o relógio de modo estendido.
```