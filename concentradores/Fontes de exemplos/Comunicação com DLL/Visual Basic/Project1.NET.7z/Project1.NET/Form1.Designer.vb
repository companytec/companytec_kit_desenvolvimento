<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> Partial Class Form1
#Region "Windows Form Designer generated code "
	<System.Diagnostics.DebuggerNonUserCode()> Public Sub New()
		MyBase.New()
		'This call is required by the Windows Form Designer.
		InitializeComponent()
	End Sub
	'Form overrides dispose to clean up the component list.
	<System.Diagnostics.DebuggerNonUserCode()> Protected Overloads Overrides Sub Dispose(ByVal Disposing As Boolean)
		If Disposing Then
			If Not components Is Nothing Then
				components.Dispose()
			End If
		End If
		MyBase.Dispose(Disposing)
	End Sub
	'Required by the Windows Form Designer
	Private components As System.ComponentModel.IContainer
	Public ToolTip1 As System.Windows.Forms.ToolTip
	Public WithEvents Text12 As System.Windows.Forms.TextBox
	Public WithEvents Text11 As System.Windows.Forms.TextBox
	Public WithEvents Command12 As System.Windows.Forms.Button
	Public WithEvents Text10 As System.Windows.Forms.TextBox
	Public WithEvents _Label1_4 As System.Windows.Forms.Label
	Public WithEvents _Label1_3 As System.Windows.Forms.Label
	Public WithEvents _Label1_2 As System.Windows.Forms.Label
	Public WithEvents Frame11 As System.Windows.Forms.GroupBox
	Public WithEvents Option1 As System.Windows.Forms.RadioButton
	Public WithEvents Command11 As System.Windows.Forms.Button
	Public WithEvents Timer1 As System.Windows.Forms.Timer
	Public WithEvents List2 As System.Windows.Forms.ListBox
	Public WithEvents Agendador As System.Windows.Forms.GroupBox
	Public WithEvents Command8 As System.Windows.Forms.Button
	Public WithEvents Text9 As System.Windows.Forms.TextBox
	Public WithEvents Text8 As System.Windows.Forms.TextBox
	Public WithEvents Label8 As System.Windows.Forms.Label
	Public WithEvents Label7 As System.Windows.Forms.Label
	Public WithEvents Frame9 As System.Windows.Forms.GroupBox
	Public WithEvents Command4 As System.Windows.Forms.Button
	Public WithEvents Command2 As System.Windows.Forms.Button
	Public WithEvents Command1 As System.Windows.Forms.Button
	Public WithEvents Frame4 As System.Windows.Forms.GroupBox
	Public WithEvents Label6 As System.Windows.Forms.Label
	Public WithEvents Frame8 As System.Windows.Forms.Panel
	Public WithEvents Text6 As System.Windows.Forms.TextBox
	Public WithEvents Command10 As System.Windows.Forms.Button
	Public WithEvents Command9 As System.Windows.Forms.Button
	Public WithEvents Label4 As System.Windows.Forms.Label
	Public WithEvents Frame7 As System.Windows.Forms.GroupBox
	Public WithEvents Command7 As System.Windows.Forms.Button
	Public WithEvents Command6 As System.Windows.Forms.Button
	Public WithEvents Command5 As System.Windows.Forms.Button
	Public WithEvents Text7 As System.Windows.Forms.TextBox
	Public WithEvents Label5 As System.Windows.Forms.Label
	Public WithEvents Frame6 As System.Windows.Forms.GroupBox
	Public WithEvents Text5 As System.Windows.Forms.TextBox
	Public WithEvents Text4 As System.Windows.Forms.TextBox
	Public WithEvents Command3 As System.Windows.Forms.Button
	Public WithEvents Label3 As System.Windows.Forms.Label
	Public WithEvents Label2 As System.Windows.Forms.Label
	Public WithEvents Frame5 As System.Windows.Forms.GroupBox
	Public WithEvents Text3 As System.Windows.Forms.TextBox
	Public WithEvents Bt_SendText As System.Windows.Forms.Button
	Public WithEvents Text2 As System.Windows.Forms.TextBox
	Public WithEvents _Label1_1 As System.Windows.Forms.Label
	Public WithEvents _Label1_0 As System.Windows.Forms.Label
	Public WithEvents Frame3 As System.Windows.Forms.GroupBox
	Public WithEvents Bt_RecText As System.Windows.Forms.Button
	Public WithEvents List1 As System.Windows.Forms.ListBox
	Public WithEvents Frame2 As System.Windows.Forms.GroupBox
	Public WithEvents Bt_OpenSerial As System.Windows.Forms.Button
	Public WithEvents Bt_CloseSocket As System.Windows.Forms.Button
	Public WithEvents Bt_CloseSerial As System.Windows.Forms.Button
	Public WithEvents Text1 As System.Windows.Forms.TextBox
	Public WithEvents Bt_OpenSocket As System.Windows.Forms.Button
	Public WithEvents Frame1 As System.Windows.Forms.GroupBox
	Public WithEvents Label1 As Microsoft.VisualBasic.Compatibility.VB6.LabelArray
	'NOTE: The following procedure is required by the Windows Form Designer
	'It can be modified using the Windows Form Designer.
	'Do not modify it using the code editor.
	<System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
		Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(Form1))
		Me.components = New System.ComponentModel.Container()
		Me.ToolTip1 = New System.Windows.Forms.ToolTip(components)
		Me.Frame11 = New System.Windows.Forms.GroupBox
		Me.Text12 = New System.Windows.Forms.TextBox
		Me.Text11 = New System.Windows.Forms.TextBox
		Me.Command12 = New System.Windows.Forms.Button
		Me.Text10 = New System.Windows.Forms.TextBox
		Me._Label1_4 = New System.Windows.Forms.Label
		Me._Label1_3 = New System.Windows.Forms.Label
		Me._Label1_2 = New System.Windows.Forms.Label
		Me.Agendador = New System.Windows.Forms.GroupBox
		Me.Option1 = New System.Windows.Forms.RadioButton
		Me.Command11 = New System.Windows.Forms.Button
		Me.Timer1 = New System.Windows.Forms.Timer(components)
		Me.List2 = New System.Windows.Forms.ListBox
		Me.Frame9 = New System.Windows.Forms.GroupBox
		Me.Command8 = New System.Windows.Forms.Button
		Me.Text9 = New System.Windows.Forms.TextBox
		Me.Text8 = New System.Windows.Forms.TextBox
		Me.Label8 = New System.Windows.Forms.Label
		Me.Label7 = New System.Windows.Forms.Label
		Me.Frame4 = New System.Windows.Forms.GroupBox
		Me.Command4 = New System.Windows.Forms.Button
		Me.Command2 = New System.Windows.Forms.Button
		Me.Command1 = New System.Windows.Forms.Button
		Me.Frame8 = New System.Windows.Forms.Panel
		Me.Label6 = New System.Windows.Forms.Label
		Me.Frame7 = New System.Windows.Forms.GroupBox
		Me.Text6 = New System.Windows.Forms.TextBox
		Me.Command10 = New System.Windows.Forms.Button
		Me.Command9 = New System.Windows.Forms.Button
		Me.Label4 = New System.Windows.Forms.Label
		Me.Frame6 = New System.Windows.Forms.GroupBox
		Me.Command7 = New System.Windows.Forms.Button
		Me.Command6 = New System.Windows.Forms.Button
		Me.Command5 = New System.Windows.Forms.Button
		Me.Text7 = New System.Windows.Forms.TextBox
		Me.Label5 = New System.Windows.Forms.Label
		Me.Frame5 = New System.Windows.Forms.GroupBox
		Me.Text5 = New System.Windows.Forms.TextBox
		Me.Text4 = New System.Windows.Forms.TextBox
		Me.Command3 = New System.Windows.Forms.Button
		Me.Label3 = New System.Windows.Forms.Label
		Me.Label2 = New System.Windows.Forms.Label
		Me.Frame3 = New System.Windows.Forms.GroupBox
		Me.Text3 = New System.Windows.Forms.TextBox
		Me.Bt_SendText = New System.Windows.Forms.Button
		Me.Text2 = New System.Windows.Forms.TextBox
		Me._Label1_1 = New System.Windows.Forms.Label
		Me._Label1_0 = New System.Windows.Forms.Label
		Me.Frame2 = New System.Windows.Forms.GroupBox
		Me.Bt_RecText = New System.Windows.Forms.Button
		Me.List1 = New System.Windows.Forms.ListBox
		Me.Frame1 = New System.Windows.Forms.GroupBox
		Me.Bt_OpenSerial = New System.Windows.Forms.Button
		Me.Bt_CloseSocket = New System.Windows.Forms.Button
		Me.Bt_CloseSerial = New System.Windows.Forms.Button
		Me.Text1 = New System.Windows.Forms.TextBox
		Me.Bt_OpenSocket = New System.Windows.Forms.Button
		Me.Label1 = New Microsoft.VisualBasic.Compatibility.VB6.LabelArray(components)
		Me.Frame11.SuspendLayout()
		Me.Agendador.SuspendLayout()
		Me.Frame9.SuspendLayout()
		Me.Frame4.SuspendLayout()
		Me.Frame8.SuspendLayout()
		Me.Frame7.SuspendLayout()
		Me.Frame6.SuspendLayout()
		Me.Frame5.SuspendLayout()
		Me.Frame3.SuspendLayout()
		Me.Frame2.SuspendLayout()
		Me.Frame1.SuspendLayout()
		Me.SuspendLayout()
		Me.ToolTip1.Active = True
		CType(Me.Label1, System.ComponentModel.ISupportInitialize).BeginInit()
		Me.Text = "DLL Companytec x Visual Basic - Companytec�/Desenvolvimento"
		Me.ClientSize = New System.Drawing.Size(840, 531)
		Me.Location = New System.Drawing.Point(4, 30)
		Me.StartPosition = System.Windows.Forms.FormStartPosition.WindowsDefaultLocation
		Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
		Me.BackColor = System.Drawing.SystemColors.Control
		Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Sizable
		Me.ControlBox = True
		Me.Enabled = True
		Me.KeyPreview = False
		Me.MaximizeBox = True
		Me.MinimizeBox = True
		Me.Cursor = System.Windows.Forms.Cursors.Default
		Me.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.ShowInTaskbar = True
		Me.HelpButton = False
		Me.WindowState = System.Windows.Forms.FormWindowState.Normal
		Me.Name = "Form1"
		Me.Frame11.Text = "VB_SendReceiveText"
		Me.Frame11.Size = New System.Drawing.Size(425, 89)
		Me.Frame11.Location = New System.Drawing.Point(4, 440)
		Me.Frame11.TabIndex = 48
		Me.Frame11.BackColor = System.Drawing.SystemColors.Control
		Me.Frame11.Enabled = True
		Me.Frame11.ForeColor = System.Drawing.SystemColors.ControlText
		Me.Frame11.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Frame11.Visible = True
		Me.Frame11.Padding = New System.Windows.Forms.Padding(0)
		Me.Frame11.Name = "Frame11"
		Me.Text12.AutoSize = False
		Me.Text12.Size = New System.Drawing.Size(281, 21)
		Me.Text12.Location = New System.Drawing.Point(136, 32)
		Me.Text12.ReadOnly = True
		Me.Text12.TabIndex = 54
		Me.Text12.AcceptsReturn = True
		Me.Text12.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
		Me.Text12.BackColor = System.Drawing.SystemColors.Window
		Me.Text12.CausesValidation = True
		Me.Text12.Enabled = True
		Me.Text12.ForeColor = System.Drawing.SystemColors.WindowText
		Me.Text12.HideSelection = True
		Me.Text12.Maxlength = 0
		Me.Text12.Cursor = System.Windows.Forms.Cursors.IBeam
		Me.Text12.MultiLine = False
		Me.Text12.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Text12.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me.Text12.TabStop = True
		Me.Text12.Visible = True
		Me.Text12.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
		Me.Text12.Name = "Text12"
		Me.Text11.AutoSize = False
		Me.Text11.Size = New System.Drawing.Size(77, 21)
		Me.Text11.Location = New System.Drawing.Point(8, 32)
		Me.Text11.TabIndex = 51
		Me.Text11.Text = "(&S)"
		Me.Text11.AcceptsReturn = True
		Me.Text11.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
		Me.Text11.BackColor = System.Drawing.SystemColors.Window
		Me.Text11.CausesValidation = True
		Me.Text11.Enabled = True
		Me.Text11.ForeColor = System.Drawing.SystemColors.WindowText
		Me.Text11.HideSelection = True
		Me.Text11.ReadOnly = False
		Me.Text11.Maxlength = 0
		Me.Text11.Cursor = System.Windows.Forms.Cursors.IBeam
		Me.Text11.MultiLine = False
		Me.Text11.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Text11.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me.Text11.TabStop = True
		Me.Text11.Visible = True
		Me.Text11.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
		Me.Text11.Name = "Text11"
		Me.Command12.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
		Me.Command12.Text = "VB_SendReceiveText"
		Me.Command12.Size = New System.Drawing.Size(281, 21)
		Me.Command12.Location = New System.Drawing.Point(136, 60)
		Me.Command12.TabIndex = 50
		Me.Command12.BackColor = System.Drawing.SystemColors.Control
		Me.Command12.CausesValidation = True
		Me.Command12.Enabled = True
		Me.Command12.ForeColor = System.Drawing.SystemColors.ControlText
		Me.Command12.Cursor = System.Windows.Forms.Cursors.Default
		Me.Command12.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Command12.TabStop = True
		Me.Command12.Name = "Command12"
		Me.Text10.AutoSize = False
		Me.Text10.Size = New System.Drawing.Size(45, 21)
		Me.Text10.Location = New System.Drawing.Point(88, 32)
		Me.Text10.TabIndex = 49
		Me.Text10.Text = "0"
		Me.Text10.AcceptsReturn = True
		Me.Text10.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
		Me.Text10.BackColor = System.Drawing.SystemColors.Window
		Me.Text10.CausesValidation = True
		Me.Text10.Enabled = True
		Me.Text10.ForeColor = System.Drawing.SystemColors.WindowText
		Me.Text10.HideSelection = True
		Me.Text10.ReadOnly = False
		Me.Text10.Maxlength = 0
		Me.Text10.Cursor = System.Windows.Forms.Cursors.IBeam
		Me.Text10.MultiLine = False
		Me.Text10.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Text10.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me.Text10.TabStop = True
		Me.Text10.Visible = True
		Me.Text10.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
		Me.Text10.Name = "Text10"
		Me._Label1_4.Text = "Resposta"
		Me._Label1_4.Size = New System.Drawing.Size(45, 13)
		Me._Label1_4.Location = New System.Drawing.Point(136, 16)
		Me._Label1_4.TabIndex = 55
		Me._Label1_4.TextAlign = System.Drawing.ContentAlignment.TopLeft
		Me._Label1_4.BackColor = System.Drawing.SystemColors.Control
		Me._Label1_4.Enabled = True
		Me._Label1_4.ForeColor = System.Drawing.SystemColors.ControlText
		Me._Label1_4.Cursor = System.Windows.Forms.Cursors.Default
		Me._Label1_4.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._Label1_4.UseMnemonic = True
		Me._Label1_4.Visible = True
		Me._Label1_4.AutoSize = True
		Me._Label1_4.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me._Label1_4.Name = "_Label1_4"
		Me._Label1_3.Text = "Comando"
		Me._Label1_3.Size = New System.Drawing.Size(45, 13)
		Me._Label1_3.Location = New System.Drawing.Point(8, 16)
		Me._Label1_3.TabIndex = 53
		Me._Label1_3.TextAlign = System.Drawing.ContentAlignment.TopLeft
		Me._Label1_3.BackColor = System.Drawing.SystemColors.Control
		Me._Label1_3.Enabled = True
		Me._Label1_3.ForeColor = System.Drawing.SystemColors.ControlText
		Me._Label1_3.Cursor = System.Windows.Forms.Cursors.Default
		Me._Label1_3.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._Label1_3.UseMnemonic = True
		Me._Label1_3.Visible = True
		Me._Label1_3.AutoSize = True
		Me._Label1_3.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me._Label1_3.Name = "_Label1_3"
		Me._Label1_2.Text = "Timeout"
		Me._Label1_2.Size = New System.Drawing.Size(38, 13)
		Me._Label1_2.Location = New System.Drawing.Point(88, 16)
		Me._Label1_2.TabIndex = 52
		Me._Label1_2.TextAlign = System.Drawing.ContentAlignment.TopLeft
		Me._Label1_2.BackColor = System.Drawing.SystemColors.Control
		Me._Label1_2.Enabled = True
		Me._Label1_2.ForeColor = System.Drawing.SystemColors.ControlText
		Me._Label1_2.Cursor = System.Windows.Forms.Cursors.Default
		Me._Label1_2.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._Label1_2.UseMnemonic = True
		Me._Label1_2.Visible = True
		Me._Label1_2.AutoSize = True
		Me._Label1_2.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me._Label1_2.Name = "_Label1_2"
		Me.Agendador.Text = "Agendador"
		Me.Agendador.Size = New System.Drawing.Size(133, 177)
		Me.Agendador.Location = New System.Drawing.Point(704, 352)
		Me.Agendador.TabIndex = 44
		Me.Agendador.BackColor = System.Drawing.SystemColors.Control
		Me.Agendador.Enabled = True
		Me.Agendador.ForeColor = System.Drawing.SystemColors.ControlText
		Me.Agendador.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Agendador.Visible = True
		Me.Agendador.Padding = New System.Windows.Forms.Padding(0)
		Me.Agendador.Name = "Agendador"
		Me.Option1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
		Me.Option1.Text = "Timer ligado"
		Me.Option1.Size = New System.Drawing.Size(101, 13)
		Me.Option1.Location = New System.Drawing.Point(8, 156)
		Me.Option1.TabIndex = 47
		Me.Option1.CheckAlign = System.Drawing.ContentAlignment.MiddleLeft
		Me.Option1.BackColor = System.Drawing.SystemColors.Control
		Me.Option1.CausesValidation = True
		Me.Option1.Enabled = True
		Me.Option1.ForeColor = System.Drawing.SystemColors.ControlText
		Me.Option1.Cursor = System.Windows.Forms.Cursors.Default
		Me.Option1.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Option1.Appearance = System.Windows.Forms.Appearance.Normal
		Me.Option1.TabStop = True
		Me.Option1.Checked = False
		Me.Option1.Visible = True
		Me.Option1.Name = "Option1"
		Me.Command11.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
		Me.Command11.Text = "Habilitar Timer"
		Me.Command11.Size = New System.Drawing.Size(117, 25)
		Me.Command11.Location = New System.Drawing.Point(8, 120)
		Me.Command11.TabIndex = 46
		Me.Command11.BackColor = System.Drawing.SystemColors.Control
		Me.Command11.CausesValidation = True
		Me.Command11.Enabled = True
		Me.Command11.ForeColor = System.Drawing.SystemColors.ControlText
		Me.Command11.Cursor = System.Windows.Forms.Cursors.Default
		Me.Command11.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Command11.TabStop = True
		Me.Command11.Name = "Command11"
		Me.Timer1.Enabled = False
		Me.Timer1.Interval = 1
		Me.List2.Size = New System.Drawing.Size(117, 98)
		Me.List2.Location = New System.Drawing.Point(8, 16)
		Me.List2.Items.AddRange(New Object(){"(&@66)"})
		Me.List2.TabIndex = 45
		Me.List2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
		Me.List2.BackColor = System.Drawing.SystemColors.Window
		Me.List2.CausesValidation = True
		Me.List2.Enabled = True
		Me.List2.ForeColor = System.Drawing.SystemColors.WindowText
		Me.List2.IntegralHeight = True
		Me.List2.Cursor = System.Windows.Forms.Cursors.Default
		Me.List2.SelectionMode = System.Windows.Forms.SelectionMode.One
		Me.List2.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.List2.Sorted = False
		Me.List2.TabStop = True
		Me.List2.Visible = True
		Me.List2.MultiColumn = False
		Me.List2.Name = "List2"
		Me.Frame9.Text = "Preset"
		Me.Frame9.Size = New System.Drawing.Size(269, 89)
		Me.Frame9.Location = New System.Drawing.Point(432, 440)
		Me.Frame9.TabIndex = 38
		Me.Frame9.BackColor = System.Drawing.SystemColors.Control
		Me.Frame9.Enabled = True
		Me.Frame9.ForeColor = System.Drawing.SystemColors.ControlText
		Me.Frame9.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Frame9.Visible = True
		Me.Frame9.Padding = New System.Windows.Forms.Padding(0)
		Me.Frame9.Name = "Frame9"
		Me.Command8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
		Me.Command8.Text = "VB_PresetPump"
		Me.Command8.Size = New System.Drawing.Size(253, 21)
		Me.Command8.Location = New System.Drawing.Point(8, 60)
		Me.Command8.TabIndex = 41
		Me.Command8.BackColor = System.Drawing.SystemColors.Control
		Me.Command8.CausesValidation = True
		Me.Command8.Enabled = True
		Me.Command8.ForeColor = System.Drawing.SystemColors.ControlText
		Me.Command8.Cursor = System.Windows.Forms.Cursors.Default
		Me.Command8.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Command8.TabStop = True
		Me.Command8.Name = "Command8"
		Me.Text9.AutoSize = False
		Me.Text9.Size = New System.Drawing.Size(49, 21)
		Me.Text9.Location = New System.Drawing.Point(8, 32)
		Me.Text9.TabIndex = 40
		Me.Text9.AcceptsReturn = True
		Me.Text9.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
		Me.Text9.BackColor = System.Drawing.SystemColors.Window
		Me.Text9.CausesValidation = True
		Me.Text9.Enabled = True
		Me.Text9.ForeColor = System.Drawing.SystemColors.WindowText
		Me.Text9.HideSelection = True
		Me.Text9.ReadOnly = False
		Me.Text9.Maxlength = 0
		Me.Text9.Cursor = System.Windows.Forms.Cursors.IBeam
		Me.Text9.MultiLine = False
		Me.Text9.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Text9.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me.Text9.TabStop = True
		Me.Text9.Visible = True
		Me.Text9.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
		Me.Text9.Name = "Text9"
		Me.Text8.AutoSize = False
		Me.Text8.Size = New System.Drawing.Size(49, 21)
		Me.Text8.Location = New System.Drawing.Point(144, 32)
		Me.Text8.TabIndex = 39
		Me.Text8.AcceptsReturn = True
		Me.Text8.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
		Me.Text8.BackColor = System.Drawing.SystemColors.Window
		Me.Text8.CausesValidation = True
		Me.Text8.Enabled = True
		Me.Text8.ForeColor = System.Drawing.SystemColors.WindowText
		Me.Text8.HideSelection = True
		Me.Text8.ReadOnly = False
		Me.Text8.Maxlength = 0
		Me.Text8.Cursor = System.Windows.Forms.Cursors.IBeam
		Me.Text8.MultiLine = False
		Me.Text8.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Text8.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me.Text8.TabStop = True
		Me.Text8.Visible = True
		Me.Text8.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
		Me.Text8.Name = "Text8"
		Me.Label8.Text = "Bico - 2 Caracteres"
		Me.Label8.Size = New System.Drawing.Size(117, 17)
		Me.Label8.Location = New System.Drawing.Point(8, 16)
		Me.Label8.TabIndex = 43
		Me.Label8.TextAlign = System.Drawing.ContentAlignment.TopLeft
		Me.Label8.BackColor = System.Drawing.SystemColors.Control
		Me.Label8.Enabled = True
		Me.Label8.ForeColor = System.Drawing.SystemColors.ControlText
		Me.Label8.Cursor = System.Windows.Forms.Cursors.Default
		Me.Label8.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Label8.UseMnemonic = True
		Me.Label8.Visible = True
		Me.Label8.AutoSize = False
		Me.Label8.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me.Label8.Name = "Label8"
		Me.Label7.Text = "Valor - 6 Caracteres"
		Me.Label7.Size = New System.Drawing.Size(117, 17)
		Me.Label7.Location = New System.Drawing.Point(144, 16)
		Me.Label7.TabIndex = 42
		Me.Label7.TextAlign = System.Drawing.ContentAlignment.TopLeft
		Me.Label7.BackColor = System.Drawing.SystemColors.Control
		Me.Label7.Enabled = True
		Me.Label7.ForeColor = System.Drawing.SystemColors.ControlText
		Me.Label7.Cursor = System.Windows.Forms.Cursors.Default
		Me.Label7.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Label7.UseMnemonic = True
		Me.Label7.Visible = True
		Me.Label7.AutoSize = False
		Me.Label7.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me.Label7.Name = "Label7"
		Me.Frame4.Text = "Comandos"
		Me.Frame4.Size = New System.Drawing.Size(133, 101)
		Me.Frame4.Location = New System.Drawing.Point(704, 248)
		Me.Frame4.TabIndex = 15
		Me.Frame4.BackColor = System.Drawing.SystemColors.Control
		Me.Frame4.Enabled = True
		Me.Frame4.ForeColor = System.Drawing.SystemColors.ControlText
		Me.Frame4.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Frame4.Visible = True
		Me.Frame4.Padding = New System.Windows.Forms.Padding(0)
		Me.Frame4.Name = "Frame4"
		Me.Command4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
		Me.Command4.Text = "VB_ReadState"
		Me.Command4.Size = New System.Drawing.Size(117, 21)
		Me.Command4.Location = New System.Drawing.Point(8, 72)
		Me.Command4.TabIndex = 24
		Me.Command4.BackColor = System.Drawing.SystemColors.Control
		Me.Command4.CausesValidation = True
		Me.Command4.Enabled = True
		Me.Command4.ForeColor = System.Drawing.SystemColors.ControlText
		Me.Command4.Cursor = System.Windows.Forms.Cursors.Default
		Me.Command4.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Command4.TabStop = True
		Me.Command4.Name = "Command4"
		Me.Command2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
		Me.Command2.Text = "VB_NextSale"
		Me.Command2.Size = New System.Drawing.Size(117, 21)
		Me.Command2.Location = New System.Drawing.Point(8, 44)
		Me.Command2.TabIndex = 17
		Me.Command2.BackColor = System.Drawing.SystemColors.Control
		Me.Command2.CausesValidation = True
		Me.Command2.Enabled = True
		Me.Command2.ForeColor = System.Drawing.SystemColors.ControlText
		Me.Command2.Cursor = System.Windows.Forms.Cursors.Default
		Me.Command2.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Command2.TabStop = True
		Me.Command2.Name = "Command2"
		Me.Command1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
		Me.Command1.Text = "VB_ReadSale"
		Me.Command1.Size = New System.Drawing.Size(117, 21)
		Me.Command1.Location = New System.Drawing.Point(8, 16)
		Me.Command1.TabIndex = 16
		Me.Command1.BackColor = System.Drawing.SystemColors.Control
		Me.Command1.CausesValidation = True
		Me.Command1.Enabled = True
		Me.Command1.ForeColor = System.Drawing.SystemColors.ControlText
		Me.Command1.Cursor = System.Windows.Forms.Cursors.Default
		Me.Command1.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Command1.TabStop = True
		Me.Command1.Name = "Command1"
		Me.Frame8.BackColor = System.Drawing.Color.FromARGB(128, 128, 128)
		Me.Frame8.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me.Frame8.Text = "Frame8"
		Me.Frame8.Size = New System.Drawing.Size(845, 81)
		Me.Frame8.Location = New System.Drawing.Point(0, 0)
		Me.Frame8.TabIndex = 36
		Me.Frame8.Enabled = True
		Me.Frame8.ForeColor = System.Drawing.SystemColors.ControlText
		Me.Frame8.Cursor = System.Windows.Forms.Cursors.Default
		Me.Frame8.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Frame8.Visible = True
		Me.Frame8.Name = "Frame8"
		Me.Label6.BackColor = System.Drawing.Color.FromARGB(128, 128, 128)
		Me.Label6.Text = "Exemplo de integra��o com DLL Companytec"
		Me.Label6.Font = New System.Drawing.Font("Verdana", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.Label6.Size = New System.Drawing.Size(437, 17)
		Me.Label6.Location = New System.Drawing.Point(4, 60)
		Me.Label6.TabIndex = 37
		Me.Label6.TextAlign = System.Drawing.ContentAlignment.TopLeft
		Me.Label6.Enabled = True
		Me.Label6.ForeColor = System.Drawing.SystemColors.ControlText
		Me.Label6.Cursor = System.Windows.Forms.Cursors.Default
		Me.Label6.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Label6.UseMnemonic = True
		Me.Label6.Visible = True
		Me.Label6.AutoSize = False
		Me.Label6.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me.Label6.Name = "Label6"
		Me.Frame7.Text = "Leitura de encerrantes"
		Me.Frame7.Size = New System.Drawing.Size(269, 85)
		Me.Frame7.Location = New System.Drawing.Point(432, 352)
		Me.Frame7.TabIndex = 31
		Me.Frame7.BackColor = System.Drawing.SystemColors.Control
		Me.Frame7.Enabled = True
		Me.Frame7.ForeColor = System.Drawing.SystemColors.ControlText
		Me.Frame7.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Frame7.Visible = True
		Me.Frame7.Padding = New System.Windows.Forms.Padding(0)
		Me.Frame7.Name = "Frame7"
		Me.Text6.AutoSize = False
		Me.Text6.Size = New System.Drawing.Size(49, 21)
		Me.Text6.Location = New System.Drawing.Point(8, 28)
		Me.Text6.TabIndex = 34
		Me.Text6.AcceptsReturn = True
		Me.Text6.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
		Me.Text6.BackColor = System.Drawing.SystemColors.Window
		Me.Text6.CausesValidation = True
		Me.Text6.Enabled = True
		Me.Text6.ForeColor = System.Drawing.SystemColors.WindowText
		Me.Text6.HideSelection = True
		Me.Text6.ReadOnly = False
		Me.Text6.Maxlength = 0
		Me.Text6.Cursor = System.Windows.Forms.Cursors.IBeam
		Me.Text6.MultiLine = False
		Me.Text6.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Text6.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me.Text6.TabStop = True
		Me.Text6.Visible = True
		Me.Text6.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
		Me.Text6.Name = "Text6"
		Me.Command10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
		Me.Command10.Text = "VB_ReadTotalsVolume"
		Me.Command10.Size = New System.Drawing.Size(125, 21)
		Me.Command10.Location = New System.Drawing.Point(136, 56)
		Me.Command10.TabIndex = 33
		Me.Command10.BackColor = System.Drawing.SystemColors.Control
		Me.Command10.CausesValidation = True
		Me.Command10.Enabled = True
		Me.Command10.ForeColor = System.Drawing.SystemColors.ControlText
		Me.Command10.Cursor = System.Windows.Forms.Cursors.Default
		Me.Command10.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Command10.TabStop = True
		Me.Command10.Name = "Command10"
		Me.Command9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
		Me.Command9.Text = "VB_ReadTotalsCash"
		Me.Command9.Size = New System.Drawing.Size(125, 21)
		Me.Command9.Location = New System.Drawing.Point(8, 56)
		Me.Command9.TabIndex = 32
		Me.Command9.BackColor = System.Drawing.SystemColors.Control
		Me.Command9.CausesValidation = True
		Me.Command9.Enabled = True
		Me.Command9.ForeColor = System.Drawing.SystemColors.ControlText
		Me.Command9.Cursor = System.Windows.Forms.Cursors.Default
		Me.Command9.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Command9.TabStop = True
		Me.Command9.Name = "Command9"
		Me.Label4.Text = "Bico - 2 Caracteres"
		Me.Label4.Size = New System.Drawing.Size(117, 17)
		Me.Label4.Location = New System.Drawing.Point(8, 12)
		Me.Label4.TabIndex = 35
		Me.Label4.TextAlign = System.Drawing.ContentAlignment.TopLeft
		Me.Label4.BackColor = System.Drawing.SystemColors.Control
		Me.Label4.Enabled = True
		Me.Label4.ForeColor = System.Drawing.SystemColors.ControlText
		Me.Label4.Cursor = System.Windows.Forms.Cursors.Default
		Me.Label4.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Label4.UseMnemonic = True
		Me.Label4.Visible = True
		Me.Label4.AutoSize = False
		Me.Label4.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me.Label4.Name = "Label4"
		Me.Frame6.Text = "Autorizar/Liberar/Bloquear"
		Me.Frame6.Size = New System.Drawing.Size(269, 85)
		Me.Frame6.Location = New System.Drawing.Point(432, 264)
		Me.Frame6.TabIndex = 25
		Me.Frame6.BackColor = System.Drawing.SystemColors.Control
		Me.Frame6.Enabled = True
		Me.Frame6.ForeColor = System.Drawing.SystemColors.ControlText
		Me.Frame6.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Frame6.Visible = True
		Me.Frame6.Padding = New System.Windows.Forms.Padding(0)
		Me.Frame6.Name = "Frame6"
		Me.Command7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
		Me.Command7.Text = "VB_AutPump"
		Me.Command7.Size = New System.Drawing.Size(80, 21)
		Me.Command7.Location = New System.Drawing.Point(8, 56)
		Me.Command7.TabIndex = 30
		Me.Command7.BackColor = System.Drawing.SystemColors.Control
		Me.Command7.CausesValidation = True
		Me.Command7.Enabled = True
		Me.Command7.ForeColor = System.Drawing.SystemColors.ControlText
		Me.Command7.Cursor = System.Windows.Forms.Cursors.Default
		Me.Command7.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Command7.TabStop = True
		Me.Command7.Name = "Command7"
		Me.Command6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
		Me.Command6.Text = "VB_BlockPump"
		Me.Command6.Size = New System.Drawing.Size(84, 21)
		Me.Command6.Location = New System.Drawing.Point(92, 56)
		Me.Command6.TabIndex = 29
		Me.Command6.BackColor = System.Drawing.SystemColors.Control
		Me.Command6.CausesValidation = True
		Me.Command6.Enabled = True
		Me.Command6.ForeColor = System.Drawing.SystemColors.ControlText
		Me.Command6.Cursor = System.Windows.Forms.Cursors.Default
		Me.Command6.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Command6.TabStop = True
		Me.Command6.Name = "Command6"
		Me.Command5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
		Me.Command5.Text = "VB_FreePump"
		Me.Command5.Size = New System.Drawing.Size(80, 21)
		Me.Command5.Location = New System.Drawing.Point(180, 56)
		Me.Command5.TabIndex = 27
		Me.Command5.BackColor = System.Drawing.SystemColors.Control
		Me.Command5.CausesValidation = True
		Me.Command5.Enabled = True
		Me.Command5.ForeColor = System.Drawing.SystemColors.ControlText
		Me.Command5.Cursor = System.Windows.Forms.Cursors.Default
		Me.Command5.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Command5.TabStop = True
		Me.Command5.Name = "Command5"
		Me.Text7.AutoSize = False
		Me.Text7.Size = New System.Drawing.Size(49, 21)
		Me.Text7.Location = New System.Drawing.Point(8, 28)
		Me.Text7.TabIndex = 26
		Me.Text7.AcceptsReturn = True
		Me.Text7.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
		Me.Text7.BackColor = System.Drawing.SystemColors.Window
		Me.Text7.CausesValidation = True
		Me.Text7.Enabled = True
		Me.Text7.ForeColor = System.Drawing.SystemColors.WindowText
		Me.Text7.HideSelection = True
		Me.Text7.ReadOnly = False
		Me.Text7.Maxlength = 0
		Me.Text7.Cursor = System.Windows.Forms.Cursors.IBeam
		Me.Text7.MultiLine = False
		Me.Text7.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Text7.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me.Text7.TabStop = True
		Me.Text7.Visible = True
		Me.Text7.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
		Me.Text7.Name = "Text7"
		Me.Label5.Text = "Bico - 2 Caracteres"
		Me.Label5.Size = New System.Drawing.Size(117, 17)
		Me.Label5.Location = New System.Drawing.Point(8, 12)
		Me.Label5.TabIndex = 28
		Me.Label5.TextAlign = System.Drawing.ContentAlignment.TopLeft
		Me.Label5.BackColor = System.Drawing.SystemColors.Control
		Me.Label5.Enabled = True
		Me.Label5.ForeColor = System.Drawing.SystemColors.ControlText
		Me.Label5.Cursor = System.Windows.Forms.Cursors.Default
		Me.Label5.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Label5.UseMnemonic = True
		Me.Label5.Visible = True
		Me.Label5.AutoSize = False
		Me.Label5.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me.Label5.Name = "Label5"
		Me.Frame5.Text = "Altera��o de pre�o"
		Me.Frame5.Size = New System.Drawing.Size(269, 81)
		Me.Frame5.Location = New System.Drawing.Point(432, 180)
		Me.Frame5.TabIndex = 18
		Me.Frame5.BackColor = System.Drawing.SystemColors.Control
		Me.Frame5.Enabled = True
		Me.Frame5.ForeColor = System.Drawing.SystemColors.ControlText
		Me.Frame5.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Frame5.Visible = True
		Me.Frame5.Padding = New System.Windows.Forms.Padding(0)
		Me.Frame5.Name = "Frame5"
		Me.Text5.AutoSize = False
		Me.Text5.Size = New System.Drawing.Size(49, 21)
		Me.Text5.Location = New System.Drawing.Point(144, 28)
		Me.Text5.TabIndex = 23
		Me.Text5.AcceptsReturn = True
		Me.Text5.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
		Me.Text5.BackColor = System.Drawing.SystemColors.Window
		Me.Text5.CausesValidation = True
		Me.Text5.Enabled = True
		Me.Text5.ForeColor = System.Drawing.SystemColors.WindowText
		Me.Text5.HideSelection = True
		Me.Text5.ReadOnly = False
		Me.Text5.Maxlength = 0
		Me.Text5.Cursor = System.Windows.Forms.Cursors.IBeam
		Me.Text5.MultiLine = False
		Me.Text5.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Text5.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me.Text5.TabStop = True
		Me.Text5.Visible = True
		Me.Text5.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
		Me.Text5.Name = "Text5"
		Me.Text4.AutoSize = False
		Me.Text4.Size = New System.Drawing.Size(49, 21)
		Me.Text4.Location = New System.Drawing.Point(8, 28)
		Me.Text4.TabIndex = 20
		Me.Text4.AcceptsReturn = True
		Me.Text4.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
		Me.Text4.BackColor = System.Drawing.SystemColors.Window
		Me.Text4.CausesValidation = True
		Me.Text4.Enabled = True
		Me.Text4.ForeColor = System.Drawing.SystemColors.WindowText
		Me.Text4.HideSelection = True
		Me.Text4.ReadOnly = False
		Me.Text4.Maxlength = 0
		Me.Text4.Cursor = System.Windows.Forms.Cursors.IBeam
		Me.Text4.MultiLine = False
		Me.Text4.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Text4.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me.Text4.TabStop = True
		Me.Text4.Visible = True
		Me.Text4.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
		Me.Text4.Name = "Text4"
		Me.Command3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
		Me.Command3.Text = "VB_SetPrice"
		Me.Command3.Size = New System.Drawing.Size(253, 21)
		Me.Command3.Location = New System.Drawing.Point(8, 52)
		Me.Command3.TabIndex = 19
		Me.Command3.BackColor = System.Drawing.SystemColors.Control
		Me.Command3.CausesValidation = True
		Me.Command3.Enabled = True
		Me.Command3.ForeColor = System.Drawing.SystemColors.ControlText
		Me.Command3.Cursor = System.Windows.Forms.Cursors.Default
		Me.Command3.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Command3.TabStop = True
		Me.Command3.Name = "Command3"
		Me.Label3.Text = "Pre�o - 4 Caracteres"
		Me.Label3.Size = New System.Drawing.Size(117, 17)
		Me.Label3.Location = New System.Drawing.Point(144, 12)
		Me.Label3.TabIndex = 22
		Me.Label3.TextAlign = System.Drawing.ContentAlignment.TopLeft
		Me.Label3.BackColor = System.Drawing.SystemColors.Control
		Me.Label3.Enabled = True
		Me.Label3.ForeColor = System.Drawing.SystemColors.ControlText
		Me.Label3.Cursor = System.Windows.Forms.Cursors.Default
		Me.Label3.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Label3.UseMnemonic = True
		Me.Label3.Visible = True
		Me.Label3.AutoSize = False
		Me.Label3.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me.Label3.Name = "Label3"
		Me.Label2.Text = "Bico - 2 Caracteres"
		Me.Label2.Size = New System.Drawing.Size(117, 17)
		Me.Label2.Location = New System.Drawing.Point(8, 12)
		Me.Label2.TabIndex = 21
		Me.Label2.TextAlign = System.Drawing.ContentAlignment.TopLeft
		Me.Label2.BackColor = System.Drawing.SystemColors.Control
		Me.Label2.Enabled = True
		Me.Label2.ForeColor = System.Drawing.SystemColors.ControlText
		Me.Label2.Cursor = System.Windows.Forms.Cursors.Default
		Me.Label2.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Label2.UseMnemonic = True
		Me.Label2.Visible = True
		Me.Label2.AutoSize = False
		Me.Label2.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me.Label2.Name = "Label2"
		Me.Frame3.Text = "VB_SendText"
		Me.Frame3.Size = New System.Drawing.Size(269, 93)
		Me.Frame3.Location = New System.Drawing.Point(432, 84)
		Me.Frame3.TabIndex = 8
		Me.Frame3.BackColor = System.Drawing.SystemColors.Control
		Me.Frame3.Enabled = True
		Me.Frame3.ForeColor = System.Drawing.SystemColors.ControlText
		Me.Frame3.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Frame3.Visible = True
		Me.Frame3.Padding = New System.Windows.Forms.Padding(0)
		Me.Frame3.Name = "Frame3"
		Me.Text3.AutoSize = False
		Me.Text3.Size = New System.Drawing.Size(45, 21)
		Me.Text3.Location = New System.Drawing.Point(216, 32)
		Me.Text3.TabIndex = 11
		Me.Text3.Text = "0"
		Me.Text3.AcceptsReturn = True
		Me.Text3.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
		Me.Text3.BackColor = System.Drawing.SystemColors.Window
		Me.Text3.CausesValidation = True
		Me.Text3.Enabled = True
		Me.Text3.ForeColor = System.Drawing.SystemColors.WindowText
		Me.Text3.HideSelection = True
		Me.Text3.ReadOnly = False
		Me.Text3.Maxlength = 0
		Me.Text3.Cursor = System.Windows.Forms.Cursors.IBeam
		Me.Text3.MultiLine = False
		Me.Text3.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Text3.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me.Text3.TabStop = True
		Me.Text3.Visible = True
		Me.Text3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
		Me.Text3.Name = "Text3"
		Me.Bt_SendText.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
		Me.Bt_SendText.Text = "VB_SendText"
		Me.Bt_SendText.Size = New System.Drawing.Size(253, 21)
		Me.Bt_SendText.Location = New System.Drawing.Point(8, 64)
		Me.Bt_SendText.TabIndex = 10
		Me.Bt_SendText.BackColor = System.Drawing.SystemColors.Control
		Me.Bt_SendText.CausesValidation = True
		Me.Bt_SendText.Enabled = True
		Me.Bt_SendText.ForeColor = System.Drawing.SystemColors.ControlText
		Me.Bt_SendText.Cursor = System.Windows.Forms.Cursors.Default
		Me.Bt_SendText.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Bt_SendText.TabStop = True
		Me.Bt_SendText.Name = "Bt_SendText"
		Me.Text2.AutoSize = False
		Me.Text2.Size = New System.Drawing.Size(205, 21)
		Me.Text2.Location = New System.Drawing.Point(8, 32)
		Me.Text2.TabIndex = 9
		Me.Text2.Text = "(&S)"
		Me.Text2.AcceptsReturn = True
		Me.Text2.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
		Me.Text2.BackColor = System.Drawing.SystemColors.Window
		Me.Text2.CausesValidation = True
		Me.Text2.Enabled = True
		Me.Text2.ForeColor = System.Drawing.SystemColors.WindowText
		Me.Text2.HideSelection = True
		Me.Text2.ReadOnly = False
		Me.Text2.Maxlength = 0
		Me.Text2.Cursor = System.Windows.Forms.Cursors.IBeam
		Me.Text2.MultiLine = False
		Me.Text2.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Text2.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me.Text2.TabStop = True
		Me.Text2.Visible = True
		Me.Text2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
		Me.Text2.Name = "Text2"
		Me._Label1_1.Text = "Enviados"
		Me._Label1_1.Size = New System.Drawing.Size(44, 13)
		Me._Label1_1.Location = New System.Drawing.Point(216, 16)
		Me._Label1_1.TabIndex = 13
		Me._Label1_1.TextAlign = System.Drawing.ContentAlignment.TopLeft
		Me._Label1_1.BackColor = System.Drawing.SystemColors.Control
		Me._Label1_1.Enabled = True
		Me._Label1_1.ForeColor = System.Drawing.SystemColors.ControlText
		Me._Label1_1.Cursor = System.Windows.Forms.Cursors.Default
		Me._Label1_1.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._Label1_1.UseMnemonic = True
		Me._Label1_1.Visible = True
		Me._Label1_1.AutoSize = True
		Me._Label1_1.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me._Label1_1.Name = "_Label1_1"
		Me._Label1_0.Text = "Comando"
		Me._Label1_0.Size = New System.Drawing.Size(45, 13)
		Me._Label1_0.Location = New System.Drawing.Point(8, 16)
		Me._Label1_0.TabIndex = 12
		Me._Label1_0.TextAlign = System.Drawing.ContentAlignment.TopLeft
		Me._Label1_0.BackColor = System.Drawing.SystemColors.Control
		Me._Label1_0.Enabled = True
		Me._Label1_0.ForeColor = System.Drawing.SystemColors.ControlText
		Me._Label1_0.Cursor = System.Windows.Forms.Cursors.Default
		Me._Label1_0.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._Label1_0.UseMnemonic = True
		Me._Label1_0.Visible = True
		Me._Label1_0.AutoSize = True
		Me._Label1_0.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me._Label1_0.Name = "_Label1_0"
		Me.Frame2.Text = "VB_ReceiveText"
		Me.Frame2.Size = New System.Drawing.Size(425, 353)
		Me.Frame2.Location = New System.Drawing.Point(4, 84)
		Me.Frame2.TabIndex = 5
		Me.Frame2.BackColor = System.Drawing.SystemColors.Control
		Me.Frame2.Enabled = True
		Me.Frame2.ForeColor = System.Drawing.SystemColors.ControlText
		Me.Frame2.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Frame2.Visible = True
		Me.Frame2.Padding = New System.Windows.Forms.Padding(0)
		Me.Frame2.Name = "Frame2"
		Me.Bt_RecText.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
		Me.Bt_RecText.Text = "VB_ReceiveText"
		Me.Bt_RecText.Size = New System.Drawing.Size(117, 21)
		Me.Bt_RecText.Location = New System.Drawing.Point(300, 324)
		Me.Bt_RecText.TabIndex = 7
		Me.Bt_RecText.BackColor = System.Drawing.SystemColors.Control
		Me.Bt_RecText.CausesValidation = True
		Me.Bt_RecText.Enabled = True
		Me.Bt_RecText.ForeColor = System.Drawing.SystemColors.ControlText
		Me.Bt_RecText.Cursor = System.Windows.Forms.Cursors.Default
		Me.Bt_RecText.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Bt_RecText.TabStop = True
		Me.Bt_RecText.Name = "Bt_RecText"
		Me.List1.Size = New System.Drawing.Size(409, 306)
		Me.List1.Location = New System.Drawing.Point(8, 16)
		Me.List1.TabIndex = 6
		Me.List1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
		Me.List1.BackColor = System.Drawing.SystemColors.Window
		Me.List1.CausesValidation = True
		Me.List1.Enabled = True
		Me.List1.ForeColor = System.Drawing.SystemColors.WindowText
		Me.List1.IntegralHeight = True
		Me.List1.Cursor = System.Windows.Forms.Cursors.Default
		Me.List1.SelectionMode = System.Windows.Forms.SelectionMode.One
		Me.List1.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.List1.Sorted = False
		Me.List1.TabStop = True
		Me.List1.Visible = True
		Me.List1.MultiColumn = False
		Me.List1.Name = "List1"
		Me.Frame1.Text = "Comunica��o"
		Me.Frame1.Size = New System.Drawing.Size(133, 161)
		Me.Frame1.Location = New System.Drawing.Point(704, 84)
		Me.Frame1.TabIndex = 0
		Me.Frame1.BackColor = System.Drawing.SystemColors.Control
		Me.Frame1.Enabled = True
		Me.Frame1.ForeColor = System.Drawing.SystemColors.ControlText
		Me.Frame1.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Frame1.Visible = True
		Me.Frame1.Padding = New System.Windows.Forms.Padding(0)
		Me.Frame1.Name = "Frame1"
		Me.Bt_OpenSerial.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
		Me.Bt_OpenSerial.Text = "VB_OpenSerial"
		Me.Bt_OpenSerial.Size = New System.Drawing.Size(117, 25)
		Me.Bt_OpenSerial.Location = New System.Drawing.Point(8, 44)
		Me.Bt_OpenSerial.TabIndex = 14
		Me.Bt_OpenSerial.BackColor = System.Drawing.SystemColors.Control
		Me.Bt_OpenSerial.CausesValidation = True
		Me.Bt_OpenSerial.Enabled = True
		Me.Bt_OpenSerial.ForeColor = System.Drawing.SystemColors.ControlText
		Me.Bt_OpenSerial.Cursor = System.Windows.Forms.Cursors.Default
		Me.Bt_OpenSerial.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Bt_OpenSerial.TabStop = True
		Me.Bt_OpenSerial.Name = "Bt_OpenSerial"
		Me.Bt_CloseSocket.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
		Me.Bt_CloseSocket.Text = "VB_CloseSocket"
		Me.Bt_CloseSocket.Size = New System.Drawing.Size(117, 25)
		Me.Bt_CloseSocket.Location = New System.Drawing.Point(8, 128)
		Me.Bt_CloseSocket.TabIndex = 4
		Me.Bt_CloseSocket.BackColor = System.Drawing.SystemColors.Control
		Me.Bt_CloseSocket.CausesValidation = True
		Me.Bt_CloseSocket.Enabled = True
		Me.Bt_CloseSocket.ForeColor = System.Drawing.SystemColors.ControlText
		Me.Bt_CloseSocket.Cursor = System.Windows.Forms.Cursors.Default
		Me.Bt_CloseSocket.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Bt_CloseSocket.TabStop = True
		Me.Bt_CloseSocket.Name = "Bt_CloseSocket"
		Me.Bt_CloseSerial.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
		Me.Bt_CloseSerial.Text = "VB_CloseSerial"
		Me.Bt_CloseSerial.Size = New System.Drawing.Size(117, 25)
		Me.Bt_CloseSerial.Location = New System.Drawing.Point(8, 100)
		Me.Bt_CloseSerial.TabIndex = 3
		Me.Bt_CloseSerial.BackColor = System.Drawing.SystemColors.Control
		Me.Bt_CloseSerial.CausesValidation = True
		Me.Bt_CloseSerial.Enabled = True
		Me.Bt_CloseSerial.ForeColor = System.Drawing.SystemColors.ControlText
		Me.Bt_CloseSerial.Cursor = System.Windows.Forms.Cursors.Default
		Me.Bt_CloseSerial.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Bt_CloseSerial.TabStop = True
		Me.Bt_CloseSerial.Name = "Bt_CloseSerial"
		Me.Text1.AutoSize = False
		Me.Text1.Size = New System.Drawing.Size(117, 21)
		Me.Text1.Location = New System.Drawing.Point(8, 16)
		Me.Text1.TabIndex = 2
		Me.Text1.AcceptsReturn = True
		Me.Text1.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
		Me.Text1.BackColor = System.Drawing.SystemColors.Window
		Me.Text1.CausesValidation = True
		Me.Text1.Enabled = True
		Me.Text1.ForeColor = System.Drawing.SystemColors.WindowText
		Me.Text1.HideSelection = True
		Me.Text1.ReadOnly = False
		Me.Text1.Maxlength = 0
		Me.Text1.Cursor = System.Windows.Forms.Cursors.IBeam
		Me.Text1.MultiLine = False
		Me.Text1.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Text1.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me.Text1.TabStop = True
		Me.Text1.Visible = True
		Me.Text1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
		Me.Text1.Name = "Text1"
		Me.Bt_OpenSocket.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
		Me.Bt_OpenSocket.Text = "VB_OpenSocket"
		Me.Bt_OpenSocket.Size = New System.Drawing.Size(117, 25)
		Me.Bt_OpenSocket.Location = New System.Drawing.Point(8, 72)
		Me.Bt_OpenSocket.TabIndex = 1
		Me.Bt_OpenSocket.BackColor = System.Drawing.SystemColors.Control
		Me.Bt_OpenSocket.CausesValidation = True
		Me.Bt_OpenSocket.Enabled = True
		Me.Bt_OpenSocket.ForeColor = System.Drawing.SystemColors.ControlText
		Me.Bt_OpenSocket.Cursor = System.Windows.Forms.Cursors.Default
		Me.Bt_OpenSocket.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Bt_OpenSocket.TabStop = True
		Me.Bt_OpenSocket.Name = "Bt_OpenSocket"
		Me.Controls.Add(Frame11)
		Me.Controls.Add(Agendador)
		Me.Controls.Add(Frame9)
		Me.Controls.Add(Frame4)
		Me.Controls.Add(Frame8)
		Me.Controls.Add(Frame7)
		Me.Controls.Add(Frame6)
		Me.Controls.Add(Frame5)
		Me.Controls.Add(Frame3)
		Me.Controls.Add(Frame2)
		Me.Controls.Add(Frame1)
		Me.Frame11.Controls.Add(Text12)
		Me.Frame11.Controls.Add(Text11)
		Me.Frame11.Controls.Add(Command12)
		Me.Frame11.Controls.Add(Text10)
		Me.Frame11.Controls.Add(_Label1_4)
		Me.Frame11.Controls.Add(_Label1_3)
		Me.Frame11.Controls.Add(_Label1_2)
		Me.Agendador.Controls.Add(Option1)
		Me.Agendador.Controls.Add(Command11)
		Me.Agendador.Controls.Add(List2)
		Me.Frame9.Controls.Add(Command8)
		Me.Frame9.Controls.Add(Text9)
		Me.Frame9.Controls.Add(Text8)
		Me.Frame9.Controls.Add(Label8)
		Me.Frame9.Controls.Add(Label7)
		Me.Frame4.Controls.Add(Command4)
		Me.Frame4.Controls.Add(Command2)
		Me.Frame4.Controls.Add(Command1)
		Me.Frame8.Controls.Add(Label6)
		Me.Frame7.Controls.Add(Text6)
		Me.Frame7.Controls.Add(Command10)
		Me.Frame7.Controls.Add(Command9)
		Me.Frame7.Controls.Add(Label4)
		Me.Frame6.Controls.Add(Command7)
		Me.Frame6.Controls.Add(Command6)
		Me.Frame6.Controls.Add(Command5)
		Me.Frame6.Controls.Add(Text7)
		Me.Frame6.Controls.Add(Label5)
		Me.Frame5.Controls.Add(Text5)
		Me.Frame5.Controls.Add(Text4)
		Me.Frame5.Controls.Add(Command3)
		Me.Frame5.Controls.Add(Label3)
		Me.Frame5.Controls.Add(Label2)
		Me.Frame3.Controls.Add(Text3)
		Me.Frame3.Controls.Add(Bt_SendText)
		Me.Frame3.Controls.Add(Text2)
		Me.Frame3.Controls.Add(_Label1_1)
		Me.Frame3.Controls.Add(_Label1_0)
		Me.Frame2.Controls.Add(Bt_RecText)
		Me.Frame2.Controls.Add(List1)
		Me.Frame1.Controls.Add(Bt_OpenSerial)
		Me.Frame1.Controls.Add(Bt_CloseSocket)
		Me.Frame1.Controls.Add(Bt_CloseSerial)
		Me.Frame1.Controls.Add(Text1)
		Me.Frame1.Controls.Add(Bt_OpenSocket)
		Me.Label1.SetIndex(_Label1_4, CType(4, Short))
		Me.Label1.SetIndex(_Label1_3, CType(3, Short))
		Me.Label1.SetIndex(_Label1_2, CType(2, Short))
		Me.Label1.SetIndex(_Label1_1, CType(1, Short))
		Me.Label1.SetIndex(_Label1_0, CType(0, Short))
		CType(Me.Label1, System.ComponentModel.ISupportInitialize).EndInit()
		Me.Frame11.ResumeLayout(False)
		Me.Agendador.ResumeLayout(False)
		Me.Frame9.ResumeLayout(False)
		Me.Frame4.ResumeLayout(False)
		Me.Frame8.ResumeLayout(False)
		Me.Frame7.ResumeLayout(False)
		Me.Frame6.ResumeLayout(False)
		Me.Frame5.ResumeLayout(False)
		Me.Frame3.ResumeLayout(False)
		Me.Frame2.ResumeLayout(False)
		Me.Frame1.ResumeLayout(False)
		Me.ResumeLayout(False)
		Me.PerformLayout()
	End Sub
#End Region 
End Class