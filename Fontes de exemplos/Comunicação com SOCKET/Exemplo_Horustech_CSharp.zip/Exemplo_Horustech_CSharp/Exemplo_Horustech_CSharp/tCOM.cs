﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO.Ports;
 
namespace WindowsFormsApplication1
{
    class tCOM
    {
        //constantes usadas para o códgio
        const int MAX_RX_LEN = 1000;

        //Variáveis usadas para detectar as portas do PC
        public string[] PortNames;  //nomes das portas
        public int PortCount = 0;   //quantidade de portas detectadas no PC

        //Variáveis usadas para receber e concatenar dados da serial
        public byte[] RxBuf = new byte[MAX_RX_LEN]; //buffer de recepção da serial
        public int RxLen; //número de bytes recebidos pela serial

        //componentes
        public static SerialPort SerialPort;
        public static ListBox ListBox;
        public static Label Label;
        

        //FUNÇÕES
        public void ListCOMs() //(ListBox listbox)
        {
            //Form1 tst = new Form1();
            //tst.listBox1.Items.Clear();
            //listbox.Items.Clear();
            
            PortNames = System.IO.Ports.SerialPort.GetPortNames(); //obtém portas seriais disponíveis no pc
            PortCount = PortNames.Length; //armazena quantas portas tenho

            int last = ListBox.SelectedIndex;
            ListBox.Items.Clear();
            for (int i = 0; i < PortCount; i++) ListBox.Items.Add(PortNames[i]); //lista as portas no componente
            Label.Text = "Nº Portas: " + PortCount.ToString(); //mostra quantas portas tenho
            if (last < PortCount) ListBox.SelectedIndex = last;
            else ListBox.SelectedIndex = -1;
        }

        public void RxEvent()
        {
            int len = SerialPort.BytesToRead;
            if ((RxLen + len) < MAX_RX_LEN)
            {
                SerialPort.Read(RxBuf, RxLen, len);
                RxLen = RxLen + len; //incrementa o número de bytes recebidos
            }
            else SerialPort.DiscardInBuffer();
        }

        public tCOM(SerialPort serialport, ListBox listbox, Label label)
        {
            SerialPort = serialport;
            ListBox = listbox;
            Label = label;
        }

    }
}
