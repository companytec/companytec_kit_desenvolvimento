﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using System.IO;  //adicionei esta lib para a porta serial detectar quantas COMs tem


//=========================================================================================================================================
// Exemplo_Horustech_CSharp
//=========================================================================================================================================
// DESCRICAO:   | Exemplo básico de uma comunicação em C#, este fonte foi feito usando porta serial e
//              | um timer com estados de máquina dentro para ler status da automação, ler abastecimento e
//              | enviar comando de incremento para o próximo abastecimeto.
//-----------------------------------------------------------------------------------------------------------------------------------------
// PROGRAMADOR: | Eng. Rafael Gebert          
//=========================================================================================================================================



namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
        public enum HrsSM {TX_INFO, RX_INFO, TX_STATUS, RX_STATUS, TX_GET_SUPPLY, RX_GET_SUPPLY, TX_INC, RX_INC, START_DELAY, WAIT_DELAY };
        tHorustech Hrs;
        tHelpers Helpers;
        tCOM Com;


        /*
         * Construtor da classe Form1
         */
        public Form1()
        {
            InitializeComponent();

            Hrs = new tHorustech();
            Helpers = new tHelpers();
            Com = new tCOM(serialPort1, listBox1, label1);

            Com.ListCOMs(); //lista as postas COM presentes no PC
            tmr_ListCOMs.Enabled = true; //ativa o timer que a cada 2segundos lista as portas serial existentes no PC
            label2.Text = "Status:";
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        /*
         * Função Básica para enviar uma string pela serial
         */
        private bool SendStr(string str)
        {
            try
            {
                if (serialPort1.IsOpen) //se a porta estiver aberta
                {
                    serialPort1.DiscardInBuffer();
                    serialPort1.Write(str);
                    Hrs.Com.RxTimeOut = 0; //limpa o timeout
                    Com.RxLen = 0; //limpa o contador de bytes vindo da serial

                    richTextBox1.AppendText("TX: " + str + "\r\n");
                    richTextBox1.ScrollToCaret();
                    return true; //informo que consegui enviar o pacote
                }
                else
                {
                    try { serialPort1.Close(); }
                    catch (Exception) { }
                    return false;
                }
            }
            catch (Exception)
            {
                try { serialPort1.Close(); }
                catch (Exception) { }
                return false;
            }
        }
        //................................................................................................................................

        /*
         * Função Básica para verificar se a string recebida (ou estou recebendo aos poucos) 
         * é um pacote válido
         */
        private bool PackageReceived()
        {

            if (Com.RxLen > 0)
            {
                //recebi um pacote válido!!!!
                if ((Com.RxBuf[0] == '>') && (Com.RxLen > 3) && (Com.RxBuf[(Com.RxLen - 1)] == '\r'))
                {
                    string str = Encoding.UTF8.GetString(Com.RxBuf, 0, Com.RxLen);
                    Hrs.RxPkg.Len = Helpers.HexAToBin(Com.RxBuf, 2, 4);
                    Hrs.RxPkg.Cmd = Helpers.HexAToByte(Com.RxBuf, 6);

                    if (Hrs.RxPkg.Len > 2) Hrs.RxPkg.DataLen = Hrs.RxPkg.Len - 2;
                    else Hrs.RxPkg.DataLen = 0;

                    //converte o checksum que veio da serial:
                    //RxBuf        :buffer com os dados vindo da serial, 
                    //(Com.RxLen-3): aponta para o primeiro caractere do checksum que veio da porta serial
                    byte rx_checksum = Helpers.HexAToByte(Com.RxBuf, Com.RxLen - 3); //checksum que recebi do pacote
                    Hrs.RxPkg.Checksum = rx_checksum;

                    //calculo do checksum: 
                    //RxBuf        :buffer com os dados vindo da serial, 
                    //1            :offset porque o caractere '>' não entra no cálculo, 
                    //(Com.RxLen-3): desconta 2bytes do checksum que veio da serial e o '\r' que não entra no cálculo
                    byte calc_checksum = Helpers.CalcChecksum(Com.RxBuf, 1, (Com.RxLen - 3)); 
                    
                    if (calc_checksum == rx_checksum)
                    { //se checksum calculado for igual ao checksum recebido, então o pacote está OK!
                        richTextBox1.AppendText("Rx: " + str);
                        richTextBox1.AppendText("\r\n");
                        richTextBox1.ScrollToCaret();
                        return true;
                    }
                    else
                    {
                        richTextBox1.AppendText("Rx: Pacote Corrompido...\r\n");
                        richTextBox1.ScrollToCaret();
                        return false;
                    }
                }
                else return false;
            }
            else return false;
        }
        //................................................................................................................................
         
        private void button1_Click(object sender, EventArgs e)
        {
            if(serialPort1.IsOpen) serialPort1.Close();  //garente que a porta vai estar fechada antes de manipular
            Hrs.Com.StateMachine = 0; //reseta o estado de máquina do protocolo
            tmr_SM.Enabled = false; //para o timer do estado de máquina

            if (listBox1.SelectedIndex >= 0)
            {
                try
                {
                    serialPort1.PortName = listBox1.SelectedItem.ToString();
                    serialPort1.BaudRate = 9600;
                    serialPort1.DtrEnable = false;
                    serialPort1.Open();
                    try { serialPort1.DtrEnable = true; }
                    catch (Exception) { serialPort1.DtrEnable = false; }
                    label2.Text = "Status: Porta Aberta!";
                    tmr_SM.Enabled = true; //se conseguir abrir a porta, liga o timer!
                }
                catch (Exception)
                {
                    label2.Text = "Status: Porta Ocupada...";
                    MessageBox.Show("Erro, a porta " + listBox1.SelectedItem.ToString() + " não pode ser aberta, talvez esteja ocupada...");
                }
            }
            else
            {
                label2.Text = "Status:";
                MessageBox.Show("Selecione uma porta válida...");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (serialPort1.IsOpen) serialPort1.Close();  //garente que a porta vai estar fechada antes de manipular
            serialPort1.DtrEnable = false;
            label2.Text = "Status: Porta Fechada.";

            Hrs.Com.StateMachine = 0; //reseta o estado de máquina do protocolo
            tmr_SM.Enabled = true; //se conseguir abrir a porta, liga o timer!
            tmr_SM.Interval = 10; //escala de tempo: 10ms
        }


        private void timer1_Tick(object sender, EventArgs e)
        {
            if (serialPort1.IsOpen == false) return; //se porta fechada, sai da função
           
            switch (Hrs.Com.StateMachine)
            {
                case (int)HrsSM.TX_INFO: 
                    if (SendStr(">?00021264") == true) //comando para ler status da automação
                    {
                        Hrs.Com.StateMachine = (int)HrsSM.RX_INFO; //vai para o estado rx para receber a resposta
                    }
                    break;//~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ 

                case (int)HrsSM.RX_INFO:
                    if (PackageReceived())
                    {
                        //recebi o dado!!!!
                        Hrs.Com.StateMachine = (int)HrsSM.TX_STATUS; //vou para o próximo estado para fazer outra pergunda
                    }
                    else if (Hrs.Com.RxTimeOut > 100) //a escala do timer está 10ms, então se eu contar 100vezes dá 1segundo
                    {
                        Hrs.Com.StateMachine = 0; //volto ao estado anterior
                        Com.RxLen = 0; //limpo qualque byte recebido
                        Hrs.Com.RxTimeOut = 0; //limpo variavel de tempo 
                    }
                    break;//~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ 

                case (int)HrsSM.TX_STATUS: 
                    if (SendStr(">?00020162") == true) //comando para ler status da automação
                    {
                        Hrs.Com.StateMachine = (int)HrsSM.RX_STATUS; //vai para o estado rx para receber a resposta
                    }
                    break;//~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ 

                case (int)HrsSM.RX_STATUS:
                    if (PackageReceived())
                    {
                        //recebi o dado!!!!
                        Hrs.Com.StateMachine = (int)HrsSM.TX_GET_SUPPLY; //vou para o próximo estado para fazer outra pergunda
                    }
                    else if (Hrs.Com.RxTimeOut > 100) //a escala do timer está 10ms, então se eu contar 100vezes dá 1segundo
                    {
                        Hrs.Com.StateMachine = 0; //volto ao estado anterior
                        Com.RxLen = 0; //limpo qualque byte recebido
                        Hrs.Com.RxTimeOut = 0; //limpo variavel de tempo 
                    }
                    break;//~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ 

                case (int)HrsSM.TX_GET_SUPPLY: //>?00020263
                    //if (SendStr("(&A)") == true) //comando para ler abastecimento
                    if (SendStr(">?00020263") == true) //comando para ler abastecimento
                    {
                        Hrs.Com.StateMachine = (int)HrsSM.RX_GET_SUPPLY; //vai para o estado rx para receber a resposta
                    }
                    break;//~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ 

                case (int)HrsSM.RX_GET_SUPPLY:
                    if (PackageReceived())
                    {
                        //recebi o pacote de dados!!!!
                        if ( (Hrs.RxPkg.Cmd==0x02) && (Hrs.RxPkg.DataLen > 0) ) //se a resposta for índice 0x02 e o campo dados for maior que zero
                        {                                                       //significa que tem um abastecimento válido para ser lido
                            Hrs.Supply.Registro = Helpers.StrToInt(Com.RxBuf, 8, 6);
                            Hrs.Supply.NrBico = (byte)Helpers.StrToInt(Com.RxBuf, 14, 2);
                            Hrs.Supply.CodComb = Helpers.HexAToByte(Com.RxBuf, 16);
                            Hrs.Supply.NrTanque = Helpers.HexAToByte(Com.RxBuf, 18);

                            Hrs.Supply.VirgTot = Helpers.StrToInt(Com.RxBuf, 36, 1);
                            Hrs.Supply.VirgVol = Helpers.StrToInt(Com.RxBuf, 37, 1);
                            Hrs.Supply.VirgPU  = Helpers.StrToInt(Com.RxBuf, 38, 1);

                            Hrs.Supply.ValorTotal  = Helpers.StrToDouble(Com.RxBuf, 20, 6, Hrs.Supply.VirgTot); //já estou convertendo para ponto flutuando considerando o código de vírgula
                            Hrs.Supply.VolumeTotal = Helpers.StrToDouble(Com.RxBuf, 26, 6, Hrs.Supply.VirgVol);
                            Hrs.Supply.Preco       = Helpers.StrToDouble(Com.RxBuf, 32, 4, Hrs.Supply.VirgPU);

                            Hrs.Supply.Tempo = Helpers.StrToInt(Com.RxBuf, 39, 4);

                            Hrs.Supply.Data = Encoding.UTF8.GetString(Com.RxBuf, 43, 2) + "/" +
                                              Encoding.UTF8.GetString(Com.RxBuf, 45, 2) + "/" +
                                              Encoding.UTF8.GetString(Com.RxBuf, 47, 2);

                            Hrs.Supply.Hora = Encoding.UTF8.GetString(Com.RxBuf, 49, 2) + ":" +
                                              Encoding.UTF8.GetString(Com.RxBuf, 51, 2);

                            Hrs.Supply.TotalizadorIni = Helpers.StrToDouble(Com.RxBuf, 53, 10, 2);
                            Hrs.Supply.TotalizadorFim = Helpers.StrToDouble(Com.RxBuf, 63, 10, 2);

                            Hrs.Supply.IdentFrentista = Encoding.UTF8.GetString(Com.RxBuf, 73, 16);
                            Hrs.Supply.IdentCliente   = Encoding.UTF8.GetString(Com.RxBuf, 89, 16);

                            Hrs.Supply.VolumeTanque = Helpers.StrToDouble(Com.RxBuf, 105, 8, 0);

                            richTextBox1.AppendText("###### ABASTECIMENTO CAPTURADO ######\r\n");
                            richTextBox1.AppendText("Hrs.Supply.Registro   \t= " + Convert.ToString(Hrs.Supply.Registro) + "\r\n");
                            richTextBox1.AppendText("Hrs.Supply.NrBico     \t= " + Convert.ToString(Hrs.Supply.NrBico) + "\r\n");
                            richTextBox1.AppendText("Hrs.Supply.CodComb    \t= " + Convert.ToString(Hrs.Supply.CodComb) + "\r\n");
                            richTextBox1.AppendText("Hrs.Supply.NrTanque   \t= " + Convert.ToString(Hrs.Supply.NrTanque) + "\r\n");
                            richTextBox1.AppendText("Hrs.Supply.VirgTot    \t= " + Convert.ToString(Hrs.Supply.VirgTot) + "\r\n");
                            richTextBox1.AppendText("Hrs.Supply.VirgVol    \t= " + Convert.ToString(Hrs.Supply.VirgVol) + "\r\n");
                            richTextBox1.AppendText("Hrs.Supply.VirgPU     \t= " + Convert.ToString(Hrs.Supply.VirgPU) + "\r\n");
                            richTextBox1.AppendText("Hrs.Supply.ValorTotal \t= " + Convert.ToString(Hrs.Supply.ValorTotal) + "\r\n");
                            richTextBox1.AppendText("Hrs.Supply.VolumeTotal\t= " + Convert.ToString(Hrs.Supply.VolumeTotal) + "\r\n");
                            richTextBox1.AppendText("Hrs.Supply.Preco      \t= " + Convert.ToString(Hrs.Supply.Preco) + "\r\n");
                            richTextBox1.AppendText("Hrs.Supply.Tempo      \t= " + Convert.ToString(Hrs.Supply.Tempo) + "\r\n");
                            richTextBox1.AppendText("Hrs.Supply.Data       \t= " + Hrs.Supply.Data + "\r\n");
                            richTextBox1.AppendText("Hrs.Supply.Hora       \t= " + Hrs.Supply.Hora + "\r\n");
                            richTextBox1.AppendText("Hrs.Supply.TotalizadorIni\t= " + Convert.ToString(Hrs.Supply.TotalizadorIni) + "\r\n");
                            richTextBox1.AppendText("Hrs.Supply.TotalizadorFim\t= " + Convert.ToString(Hrs.Supply.TotalizadorFim) + "\r\n");
                            richTextBox1.AppendText("Hrs.Supply.IdentFrentista\t= " + Hrs.Supply.IdentFrentista + "\r\n");
                            richTextBox1.AppendText("Hrs.Supply.IdentCliente  \t= " + Hrs.Supply.IdentCliente + "\r\n");
                            richTextBox1.AppendText("Hrs.Supply.VolumeTanque  \t= " + Convert.ToString(Hrs.Supply.VolumeTanque) + "\r\n");
                            richTextBox1.AppendText("\r\n\r\n");
                            richTextBox1.ScrollToCaret();
                            Hrs.Com.StateMachine = (int)HrsSM.TX_INC; //vou para o estado de enviar incremento
                        }
                        else
                        { //se caí aqui dentro, não tem mais abastecimento para ler
                          Hrs.Com.StateMachine = (int)HrsSM.START_DELAY; //vou para um estado de delay antes de voltar para o primeiro estado
                        }
                    }
                    else if (Hrs.Com.RxTimeOut > 100) //a escala do timer está 10ms, então se eu contar 100vezes dá 1segundo
                    {
                        Hrs.Com.StateMachine = (int)HrsSM.TX_GET_SUPPLY; //volto ao estado anterior
                        Com.RxLen = 0; //limpo qualque byte recebido
                        Hrs.Com.RxTimeOut = 0; //limpo variavel de tempo 
                    }
                    break;//~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ 

                case (int)HrsSM.TX_INC: 
                    if (SendStr(">?00020667") == true) //comando para enviar incremento para ler próximo abast
                    {
                        Hrs.Com.StateMachine = (int)HrsSM.RX_INC; //espero resposta do incremento
                    }
                    break;//~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ 

                case (int)HrsSM.RX_INC:
                    if (PackageReceived())
                    {
                        Hrs.Com.StateMachine = (int)HrsSM.TX_GET_SUPPLY; //volta para ler próximo abast
                    }
                    else if (Hrs.Com.RxTimeOut > 100) //a escala do timer está 10ms, então se eu contar 100vezes dá 1segundo
                    {
                        Hrs.Com.StateMachine = (int)HrsSM.TX_GET_SUPPLY; //volto a ler o abastecimento para ver se ainda é o mesmo registro
                        Com.RxLen = 0; //limpo qualque byte recebido
                        Hrs.Com.RxTimeOut = 0; //limpo variavel de tempo 
                    }
                    break;//~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ 


                case (int)HrsSM.START_DELAY: //estado de máquina para gerar um atraso antes de reiniciar o ciclo para zero
                         //o interessante de fazer um estado desse tipo é que o aplicativo não fica travado
                         //com comandos como sleep e por isso não precisa de thread!
                    Hrs.Com.WaitTimeOut = 0;
                    Hrs.Com.StateMachine = (int)HrsSM.WAIT_DELAY; //vai para o próximo estado que conta para esperar o tempo passar
                    break;//~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ 

                case (int)HrsSM.WAIT_DELAY: //estado de máquina que conta para esperar o tempo passar
                    Hrs.Com.WaitTimeOut++;
                    if (Hrs.Com.WaitTimeOut > 100) //a escala do timer está 10ms, então se eu contar 100vezes dá 1segundo
                    {
                        Hrs.Com.StateMachine = 0; 
                    }
                    break;//~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ 

                default:
                    //StateMachine = 0; //protecao: se estourar a variável estado de máquina
                                      //volta para zero
                    break;//~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ 
            }//fim switch


            //...........................//
            Hrs.Com.RxTimeOut++; //não remover
            //..........................//
        }

        private void serialPort1_DataReceived(object sender, System.IO.Ports.SerialDataReceivedEventArgs e)
        {
            Com.RxEvent();
        }

        private void tmr_ListCOMs_Tick(object sender, EventArgs e)
        {
            Com.ListCOMs();
        }
    }
}
