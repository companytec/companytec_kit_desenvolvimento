﻿/*
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
*/
 
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using System.IO;  //adicionei esta lib para a porta serial detectar quantas COMs tem

namespace WindowsFormsApplication1
{
    class tHelpers
    {
        public byte HexAToByte(byte[] ascii_buf)
        {
            //Copy data
            byte[] buf = new byte[2];
            buf[0] = ascii_buf[0];
            buf[1] = ascii_buf[1];

            // Convert lowercase to uppercase
            if (buf[0] > 'F') buf[0] -= 'a' - 'A'; //high
            if (buf[1] > 'F') buf[1] -= 'a' - 'A'; //low

            // Convert 0-9, A-F to 0x0-0xF
            if (buf[0] > '9') buf[0] -= 'A' - 10;
            else buf[0] -= '0' - 0;
            if (buf[1] > '9') buf[1] -= 'A' - 10;
            else buf[1] -= '0' - 0;

            // Concatenate
            return (byte)((buf[0] << 4) | buf[1]);
        }
        //--------------------------------------------------------------------

        public byte HexAToByte(byte[] ascii_buf, int offset)
        {
            //Copy data
            byte[] buf = new byte[2];
            buf[0] = ascii_buf[(offset + 0)];
            buf[1] = ascii_buf[(offset + 1)];

            // Convert lowercase to uppercase
            if (buf[0] > 'F') buf[0] -= 'a' - 'A'; //high
            if (buf[1] > 'F') buf[1] -= 'a' - 'A'; //low

            // Convert 0-9, A-F to 0x0-0xF
            if (buf[0] > '9') buf[0] -= 'A' - 10;
            else buf[0] -= '0' - 0;
            if (buf[1] > '9') buf[1] -= 'A' - 10;
            else buf[1] -= '0' - 0;
            // Concatenate
            return (byte)((buf[0] << 4) | buf[1]);
        }
        //--------------------------------------------------------------------

        public int HexAToBin(byte[] ascii_buf, int offset, int ascii_digits)
        {
            int i, val, shift_val;
            byte result;

            if (ascii_digits >= 2)
            {   //se o nº de digitos é impar, forço para par já que bytes HEXA são de dois em dois caracteres
                if ((ascii_digits & 1) == 1) ascii_digits--;
                shift_val = ((ascii_digits / 2) - 1) * 8;
            }
            else return 0;

            for (i=0, val=0; i < ascii_digits; i+=2)
            {
                result = HexAToByte(ascii_buf, offset+i);
                val = val + (int)(result << shift_val);
                if (shift_val >= 8) shift_val = shift_val - 8;
                else shift_val = 0;
            }
            return val;
        }
        //--------------------------------------------------------------------

        public int StrToInt(byte[] buf, int offset, int digits)
        {
            if (digits == 0) return 0;

            int val, result = 0;
            for (int i = 0; i < digits; i++)
            {
                val = (int)buf[(i+offset)] - '0';
                result = result * 10 + val;
            }
            return result;
        }
        //--------------------------------------------------------------------

        public double StrToDouble(byte[] buf, int offset, int total_digits, int float_digits)
        {
            double val_div = Math.Pow(10, float_digits);
            return ((double)StrToInt(buf, offset, total_digits)/val_div);
        }
        //--------------------------------------------------------------------

        public byte CalcChecksum(byte[] buf, int len)
        {
            byte checksum = 0;
            for (int i = 0; i < len; i++) checksum += buf[i];
            return checksum;
        }
        //--------------------------------------------------------------------

        public byte CalcChecksum(byte[] buf, int offset, int len)
        {
            byte checksum = 0;
            for (int i = offset; i < len; i++) checksum += buf[i];
            return checksum;
        }
        //--------------------------------------------------------------------

        public string StrChecksum(string str)
        {
            int len = str.Length;
            byte[] tmp = new byte[1];
            tmp[0] = 0;
            for (int i = 0; i < len; i++)
            {
                tmp[0] += Convert.ToByte(str[i]);
            }
            return BitConverter.ToString(tmp).Replace("-", "");
        }
        //--------------------------------------------------------------------
    }
}
