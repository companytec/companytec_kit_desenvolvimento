﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;


using System.IO;  //adicionei esta lib para a porta serial detectar quantas COMs tem


namespace WindowsFormsApplication1
{
    class tHorustech
    {
        /*
         * Estrutura de comunicação: Variáveis de controle do fluxo de perguntas/respostas entre aplicativo e automação
         *                           Os estados são chamdos por um timer 'tmr_SM' no 'Form1.cs' em uma base de tempo de 10ms
         */
        public struct tCom
        {
            public int StateMachine;   //estados de máquina do protocolo
            public int RxTimeOut; //variável de contagem de tempo para o timeout (escala de tempo depende do interval do timer)
            public int WaitTimeOut; //variável de contagem de tempo para aguardar antes de fazer algo
        }
        public tCom Com = new tCom();


        /*
         * Estrutura de comunicação: Cabeçalho de esposta do protocolo Horustech. 
         *                           Essas variáeis são carregadas pela função PackageReceived() 'Form1.cs'
         */
        public struct tRxPkg
        {
            public int Len;  //número de bytes vindos da resposta da automação (incluindo o comando)
            public byte Cmd; //índice do comando de resposta da automação
            public byte Checksum; //checksum que veio no final da resposta da automação (já convertido de hexa ascii para byte -> função HexAToByte)

            public int DataLen; //número de bytes no campo de dados (sem o comando)
        }
        public tRxPkg RxPkg = new tRxPkg();
        

        /*
         * Estrutura de dados de abastecimento
         */
        public struct tSupply
        {
            public int Registro; // NNNNNN [6]: Índice do abastecimento na memória da automação
            public byte NrBico; //BB [2]: Número do bico
            public byte CodComb; //CC [2]: Código do combustível
            public byte NrTanque; //AA [2]: Número do tanque fornecedor do bico
            public double ValorTotal; //TTTTTT [6]: Valor total abastecido
            public double VolumeTotal; //LLLLLL [6]: Volume total fornecido
            public double Preco; //PPPP [4]: Preço unitário praticado;

            public int VirgTot; //vvv [3]: Número de casas decimais do campo total
            public int VirgVol; //vvv [3]: Número de casas decimais do campo volume
            public int VirgPU;  //vvv [3]: Número de casas decimais do campo preço unitário

            public int Tempo; //tttt [4]: Tempo de duração do abastecimento;
            public string Data; //ddmmyyhhnn [10]: Data completa do abastecimento
            public string Hora; //ddmmyyhhnn [10]: Data completa do abastecimento
            public double TotalizadorIni;
            public double TotalizadorFim;
            public string IdentFrentista;
            public string IdentCliente;
            public double VolumeTanque;
        }
        public tSupply Supply = new tSupply();



        /*
         * Construtor da Classe
         */ 
        public tHorustech() 
        {
            Com.StateMachine = 0;
            Com.RxTimeOut = 0;
            Com.WaitTimeOut = 0;
        }
    }
}
