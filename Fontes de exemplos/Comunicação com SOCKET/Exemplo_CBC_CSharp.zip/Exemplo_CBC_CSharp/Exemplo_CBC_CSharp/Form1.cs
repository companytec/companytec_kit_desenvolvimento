﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Net.Sockets;

using System.IO;  //adicionei esta lib para a porta serial detectar quantas COMs tem


//=========================================================================================================================================
// Exemplo_CBC_CSharp
//=========================================================================================================================================
// DESCRICAO:   | Exemplo básico de uma comunicação em C#, este fonte foi feito usando porta serial e
//              | um timer com estados de máquina dentro para ler status da automação, ler abastecimento e
//              | enviar comando de incremento para o próximo abastecimeto.
//-----------------------------------------------------------------------------------------------------------------------------------------
// PROGRAMADOR: | Eng. Rafael Gebert          
//=========================================================================================================================================



namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
        public static string[] PortNames;
        public static int PortCount = 0;

        public static int StateMachine = 0;   //estados de máquina do protocolo
        public static int RxTimeOut = 0; //variável de contagem de tempo para o timeout (escala de tempo depende do interval do timer)
        public static int WaitTimeOut = 0; //variável de contagem de tempo para aguardar antes de fazer algo

        public static char[] RxBuf = new char[1000]; //buffer de recepção da serial
        public static int RxLen; //número de bytes recebidos pela serial
        public static Boolean IsConnected;
        public static TcpClient tcpConnection;
        public static NetworkStream stream;

        /*
         * Função Básica para enviar uma string pela serial
         */
        private bool SendStr(string str)
        {
            try
            {
                if (serialPort1.IsOpen) //se a porta estiver aberta
                {
                    serialPort1.DiscardInBuffer();
                    serialPort1.Write(str);
                    RxTimeOut = 0; //limpa o timeout
                    RxLen = 0; //limpa o contador de bytes vindo da serial

                    richTextBox1.AppendText("TX: " + str + "\r\n");
                    return true; //informo que consegui enviar o pacote
                }
                else
                {
                    if (tcpConnection.Connected)
                    {
                        stream.Write(Encoding.ASCII.GetBytes(str), 0, str.Length);
                        RxTimeOut = 0; //limpa o time
                        RxLen = 0; //limpa o contador de bytes vindo da ethernet
                        richTextBox1.AppendText("TX: " + str + "\r\n");
                        return true;

                    }
                    return false;
                    /*
                    try { serialPort1.Close(); }
                    catch (Exception) { }
                    return false;
                     */
                }
            }
            catch (Exception)
            {
                try { serialPort1.Close(); }
                catch (Exception) { }
                return false;
            }
        }
        //................................................................................................................................

        /*
         * Função Básica para verificar se a string recebida (ou estou recebendo aos poucos) 
         * é um pacote válido
         */
        private bool PackageReceived()
        {
            if (RxLen > 0)
            {
                if (RxBuf[0] == '(' && RxBuf[(RxLen - 1)] == ')')
                {   //recebi o dado!!!!
                    RxBuf[(RxLen)] = '\0';
                    string s = new string(RxBuf);
                    richTextBox1.AppendText("RX: " + s);
                    richTextBox1.AppendText("\r\n");
                    return true;
                }
                else return false;
            }
            else return false;
        }
        //................................................................................................................................

        public Form1()
        {
            InitializeComponent();

            PortNames = System.IO.Ports.SerialPort.GetPortNames(); //obtém portas seriais disponíveis no pc
            PortCount = PortNames.Length; //armazena quantas portas tenho

            for(int i=0; i<PortCount; i++) listBox1.Items.Add(PortNames[i]); //lista as portas no componente
            label1.Text = "Nº Portas: " + PortCount.ToString(); //mostra quantas portas tenho

            label2.Text = "Status:";

            tcpConnection = new TcpClient();


           
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if(serialPort1.IsOpen) serialPort1.Close();  //garente que a porta vai estar fechada antes de manipular
            StateMachine = 0; //reseta o estado de máquina do protocolo
            timer1.Enabled = false; //para o timer do estado de máquina

            if (listBox1.SelectedIndex >= 0)
            {
                try
                {
                    serialPort1.PortName = listBox1.SelectedItem.ToString();
                    serialPort1.BaudRate = 9600;
                    serialPort1.DtrEnable = false;
                    serialPort1.Open();
                    try { serialPort1.DtrEnable = true; }
                    catch (Exception) { serialPort1.DtrEnable = false; }
                    label2.Text = "Status: Porta Aberta!";
                    timer1.Enabled = true; //se conseguir abrir a porta, liga o timer!
                    RxTimer1.Enabled = true;
                    button1.Enabled = false;
                    button2.Enabled = true;
                }
                catch (Exception)
                {
                    label2.Text = "Status: Porta Ocupada...";
                    MessageBox.Show("Erro, a porta " + listBox1.SelectedItem.ToString() + " não pode ser aberta, talvez esteja ocupada...");
                }
            }
            else
            {
                label2.Text = "Status:";
                MessageBox.Show("Selecione uma porta válida...");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (serialPort1.IsOpen) serialPort1.Close();  //garente que a porta vai estar fechada antes de manipular
            serialPort1.DtrEnable = false;
            label2.Text = "Status: Porta Fechada.";

            StateMachine = 0; //reseta o estado de máquina do protocolo
            timer1.Enabled = true; //se conseguir abrir a porta, liga o timer!
            timer1.Interval = 10; //escala de tempo: 10ms
            button2.Enabled = false;
            button1.Enabled = true;
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }


        private void timer1_Tick(object sender, EventArgs e)
        {
            if (serialPort1.IsOpen == false  && tcpConnection.Connected == false ) return; //se porta fechada, sai da função

            switch (StateMachine)
            {
                case 0:
                    if (SendStr("(&S)") == true) //comando para ler status da automação
                    {
                        StateMachine = 1; //vai para o estado rx para receber a resposta
                    }
                    break;//~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ 

                case 1:
                    if (PackageReceived())
                    {
                        //recebi o dado!!!!
                        StateMachine = 2; //vou para o próximo estado para fazer outra pergunda
                    }
                    else if (RxTimeOut > 100) //a escala do timer está 10ms, então se eu contar 100vezes dá 1segundo
                    {
                        StateMachine = 0; //volto ao estado anterior
                        RxLen = 0; //limpo qualque byte recebido
                        RxTimeOut = 0; //limpo variavel de tempo 
                    }
                    break;//~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ 

                case 2:
                    if (SendStr("(&A)") == true) //comando para ler abastecimento
                    {
                        StateMachine = 3; //vai para o estado rx para receber a resposta
                    }
                    break;//~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ 

                case 3:
                    if (PackageReceived())
                    {
                        //recebi o dado!!!!
                        if (RxBuf[0] == '(' && RxBuf[1] == '0' && RxBuf[2] == ')')
                        {   //se caí aqui dentro, não tem mais abastecimento para ler
                            StateMachine = 99; //vou para um estado de delay antes de voltar para o primeiro estado
                        }
                        else StateMachine = 4; //vou para o estado de enviar incremento
                    }
                    else if (RxTimeOut > 100) //a escala do timer está 10ms, então se eu contar 100vezes dá 1segundo
                    {
                        StateMachine = 2; //volto ao estado anterior
                        RxLen = 0; //limpo qualque byte recebido
                        RxTimeOut = 0; //limpo variavel de tempo 
                    }
                    break;//~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ 

                case 4:
                    if (SendStr("(&I)") == true) //comando para enviar incremento para ler próximo abast
                    {
                        StateMachine = 2; //volta para ler próximo abast
                        //obs: este comando não tem resposta....
                    }
                    break;//~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ 

                case 5:
                    if (PackageReceived())
                    {
                        //recebi o dado!!!!
                        string s = new string(RxBuf);
                        if (s != "(0)")
                        {
                            StateMachine = 4; //vou para o estado de enviar incremento
                        }
                        else StateMachine = 99; //vou para o próximo estado para fazer outra pergunda
                    }
                    else if (RxTimeOut > 100) //a escala do timer está 10ms, então se eu contar 100vezes dá 1segundo
                    {
                        StateMachine = 2; //volto ao estado anterior
                        RxLen = 0; //limpo qualque byte recebido
                        RxTimeOut = 0; //limpo variavel de tempo 
                    }
                    break;//~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ 


                case 99: //estado de máquina para gerar um atraso antes de reiniciar o ciclo para zero
                         //o interessante de fazer um estado desse tipo é que o aplicativo não fica travado
                         //com comandos como sleep e por isso não precisa de thread!
                    WaitTimeOut = 0;
                    StateMachine = 100; //vai para o próximo estado que conta para esperar o tempo passar
                    break;//~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ 

                case 100: //estado de máquina que conta para esperar o tempo passar
                    WaitTimeOut++;
                    if (WaitTimeOut > 150) //a escala do timer está 10ms, então se eu contar 150vezes dá 1,5segundos
                    {
                        StateMachine = 0; 
                    }
                    break;//~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ 

                default:
                    //StateMachine = 0; //protecao: se estourar a variável estado de máquina
                                      //volta para zero
                    break;//~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ 
            }//fim switch


            //...........................//
              RxTimeOut++; //não remover
            //..........................//
        }

        private void serialPort1_DataReceived(object sender, System.IO.Ports.SerialDataReceivedEventArgs e)
        {/*
            int len = serialPort1.BytesToRead;
            serialPort1.Read(RxBuf, RxLen, len);
            RxLen = RxLen + len; //incrementa o número de bytes recebidos */
        }

        private void button3_Click(object sender, EventArgs e)
        {
            timer1.Enabled = false;
            if (IsConnected)
            {
                if (serialPort1.IsOpen) serialPort1.Close();  //garente que a porta vai estar fechada antes de manipular
                else
                {
                    tcpConnection.Close();
         
                }
            }

            IsConnected = false;
            try
            {
                if(IsConnected)
                {
                    tcpConnection.GetStream().Close();
                    tcpConnection.Close();
                }
                tcpConnection = new TcpClient();
                tcpConnection.Connect(IpText.Text, 1771);
            }
            catch (Exception )
            {
                richTextBox1.AppendText("Error :" + IpText.Text);
            }

            

            if(tcpConnection.Connected)
            {
                stream = tcpConnection.GetStream();
                IsConnected = true;
                timer1.Enabled = true;
                RxTimer1.Enabled = true;


            }
        }

        private void backgroundWorker1_DoWork(object sender, DoWorkEventArgs e)
        {

        }

        private void RxTimer(object sender, EventArgs e)
        {
           

        }

        private void RxTimerTick(object sender, EventArgs e)
        {
            Byte[] bytes = new Byte[1024];

            if (!IsConnected) return;

            if (serialPort1.IsOpen)
            {
                int len = serialPort1.BytesToRead;
                serialPort1.Read(RxBuf, RxLen, len);
                RxLen = RxLen + len; //incrementa o número de bytes recebidos

            }
            else
            {
                int len = tcpConnection.Available;
                if (len > 0 )
                {
                    stream.Read(bytes, 0, len);
                    RxBuf = System.Text.Encoding.UTF8.GetString(bytes).ToCharArray();
                    RxLen = RxLen + len;
                }

            }
            
        }

        private void CloseTCP_Click(object sender, EventArgs e)
        {
            timer1.Enabled = false;
            RxTimer1.Enabled = false;
            IsConnected = false;
            tcpConnection.GetStream().Close();
            tcpConnection.Close();
            //tcpConnection.Dispose();
            tcpConnection = null;
          
     
        }
    }
}
